package com.hafiz.childrenapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class QuizActivity extends AppCompatActivity {
    private int res1;
    private int res2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        Random r = new Random();
        int low1 = 1;
        int high1 = 11;
        int result1 = r.nextInt(high1-low1) + low1;
        int low2 = 1;
        int high2 = 11;
        int result2 = r.nextInt(high2-low2) + low2;
        this.res1 = result1;
        this.res2 = result2;
        TextView textView2 = findViewById(R.id.textView2);
        String str = result1 + " x " + result2;
        textView2.setText(str);
    }

    public void btnClick1(View view){
        Intent intent = new Intent(QuizActivity.this, QuizActivity2.class);
        EditText editText1 = findViewById(R.id.editText1);
        String str = editText1.getText().toString();
        if(str.isEmpty()){
            Toast toast=Toast.makeText(getApplicationContext(),"Please enter your answer.",Toast.LENGTH_SHORT);
            toast.show();
        }else{
            int product = Integer.parseInt(str);
            Toast toast=Toast.makeText(getApplicationContext(),"Your Answer is " + product,Toast.LENGTH_SHORT);
            toast.show();

            if(product == (getRes1() * getRes2()) ){
                intent.putExtra("RESULT", 1);
            }else{
                intent.putExtra("RESULT", 0);
            }
            startActivity(intent);
        }
    }

    @SuppressLint("Missing Super Call")
    @Override
    public void onBackPressed(){

    }

    int getRes1(){
        return this.res1;
    }

    int getRes2(){
        return this.res2;
    }
}