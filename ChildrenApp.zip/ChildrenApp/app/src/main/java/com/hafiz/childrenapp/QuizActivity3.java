package com.hafiz.childrenapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class QuizActivity3 extends AppCompatActivity {
    private int res1;
    private int res2;
    private int r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz3);
        Intent intent = getIntent();
        this.r = intent.getIntExtra("RESULT", 0);
        Random r = new Random();
        int low1 = 1;
        int high1 = 11;
        int result1 = r.nextInt(high1-low1) + low1;
        int low2 = 1;
        int high2 = 11;
        int result2 = r.nextInt(high2-low2) + low2;
        this.res1 = result1;
        this.res2 = result2;
        TextView textView6 = findViewById(R.id.textView6);
        String str = result1 + " x " + result2;
        textView6.setText(str);
    }

    public void btnClick3(View view){
        Intent intent = new Intent(QuizActivity3.this, QuizResult.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        EditText editText3 = findViewById(R.id.editText3);
        String str = editText3.getText().toString();
        if(str.isEmpty()){
            Toast toast=Toast.makeText(getApplicationContext(),"Please enter your answer.",Toast.LENGTH_SHORT);
            toast.show();
        }else{
            int product = Integer.parseInt(str);
            Toast toast=Toast.makeText(getApplicationContext(),"Your Answer is " + product,Toast.LENGTH_SHORT);
            toast.show();
            if(product == (res1 * res2) ){
                this.r += 1;
                intent.putExtra("RESULT", this.r);
            }else{
                intent.putExtra("RESULT", this.r);
            }
            startActivity(intent);
        }
    }

    @SuppressLint("Missing Super Call")
    @Override
    public void onBackPressed(){

    }
}