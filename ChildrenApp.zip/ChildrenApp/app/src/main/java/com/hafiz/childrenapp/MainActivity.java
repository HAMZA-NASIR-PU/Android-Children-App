package com.hafiz.childrenapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Get id of ListView.
        ListView myListView = findViewById(R.id.myListView);
        ArrayList<String> table_of_contents = new ArrayList<>();
        table_of_contents.add("Table of 1");
        table_of_contents.add("Table of 2");
        table_of_contents.add("Table of 3");
        table_of_contents.add("Table of 4");
        table_of_contents.add("Table of 5");
        table_of_contents.add("Table of 6");
        table_of_contents.add("Table of 7");
        table_of_contents.add("Table of 8");
        table_of_contents.add("Table of 9");
        table_of_contents.add("Table of 10");
        table_of_contents.add("Start Quiz");

        //Create Array Adapter.
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, table_of_contents);
        myListView.setAdapter(arrayAdapter);

        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position < 10){
                    Intent intent = new Intent(MainActivity.this, ShowTable.class);
                    intent.putExtra("TABLE_NUMBER", position);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(MainActivity.this, QuizActivity.class);
                    startActivity(intent);
                }
            }
        });
    }
}