package com.hafiz.childrenapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class QuizResult extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_result);
        Intent intent = getIntent();
        TextView textView7 = findViewById(R.id.textView7);
        int res = intent.getIntExtra("RESULT", 0);
        textView7.setText("Correct Answers: " + res  + "/3");
    }

    @SuppressLint("Missing Super Call")
    @Override
    public void onBackPressed(){

    }
}